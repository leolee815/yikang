<?php
/**
 * Created by PhpStorm.
 * User: heqing
 * Date: 15/7/31
 * Time: 09:42
 */

return array(
    'info' => array(
        'name' => 'SystemInfo',
        'title' => '系统信息',
        'description' => '系统信息插件',
        'status' => 1,
        'author' => 'better',
        'version' => '0.1'
    ),
);