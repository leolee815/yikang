<?php
/**
 * Created by PhpStorm.
 * User: heqing
 * Date: 15/7/31
 * Time: 09:42
 */

return array(
    'info' => array(
        'name' => 'Vote',
        'title' => '投票',
        'description' => '投票插件',
        'status' => 1,
        'author' => 'better',
        'version' => '0.1'
    ),
);