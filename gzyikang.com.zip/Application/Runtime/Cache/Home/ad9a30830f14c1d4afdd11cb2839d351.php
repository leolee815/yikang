<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>登陆页</title>
	</head>
	<body>
		<h3>App</h3>
		<p><?php echo hook('tt');?></p>
		<p><?php echo hook('demo');?></p>
		
	</body>
</html>